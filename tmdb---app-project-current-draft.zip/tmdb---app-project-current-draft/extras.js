// <Text style={{color: 'white', fontSize: 15, fontWeight: 'bold',marginBottom: 10}}> -1 Release Date Year</Text>
    //   <Chip onPress={() => decrementYear() }>                   -1 Release Date Year                             </Chip>

    //  <Text style={{color: 'white', fontSize: 15, fontWeight: 'bold',marginBottom: 10}}> +1 Release Date Year</Text>
    //   <Chip onPress={() => add1Year()}>                   +1 Release Date Year                             </Chip>

    //   <Text style={{color: 'white', fontSize: 15, fontWeight: 'bold',marginBottom: 10}}> -10 Release Date Year</Text>
    //   <Chip onPress={() => decrement10Year()}>                   -10 Release Date Year                             </Chip>

    //  <Text style={{color: 'white', fontSize: 15, fontWeight: 'bold',marginBottom: 10}}> +10 Release Date Year</Text>
    //   <Chip onPress={() => add10Year()}>                   +10 Release Date Year                             </Chip>

//Things to ask

    //  how to make the movies come up in alphabetical order

    //  how to add the photo to each card

    //<Text>Photo: {item.poster_path}</Text>

    //   how to make it look the same on the phone

    //  how to make the top rated moveis show up first

    //   how too bold the titles 

    //  how to change the color of the Chips

    // how to make chips/buttons smaller

    //  how to put the year under the year ajuster buttons so ppl can see what year they are on

    //https://wallup.net/wp-content/uploads/2018/03/19/580205-blurred-colorful-vertical-portrait_display-748x1330.jpg

    