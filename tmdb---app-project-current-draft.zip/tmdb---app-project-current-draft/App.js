import * as React from 'react';
import { Text, View, Button, StyleSheet, FlatList, Dimensions, Image, SafeAreaView, TouchableOpacity, ScrollView, CheckBox, ImageBackground } from 'react-native';
import Constants from 'expo-constants';
import FileSystem from 'expo';
import {useState, useEffect} from 'react';
import axios from 'axios';
import { SearchBar } from 'react-native-elements';
import { Dropdown } from 'react-native-elements';
import { Chip } from 'react-native-paper';

const TMDB_KEY = "fe14f4c4865741ebad483aaa4bbf6b86";
const image = { uri: "https://wallup.net/wp-content/uploads/2018/03/19/580205-blurred-colorful-vertical-portrait_display-748x1330.jpg" };

const genres = {
    "action_genres": 28,
    "adventure_genres": 12,
    "animation_genres": 16,
    "comedy_genres": 35,
    "crime_genres": 80,
    "documentary_genres": 99,
    "drama_genres": 18,
    "family_genres": 10751,
    "fantasy_genres": 14,
    "history_genres": 36,
    "horror_genres": 27,
    "music_genres": 10402,
    "mystery_genres": 9648,
    "romance_genres": 10749,
    "sciencefiction_genres": 878,
    "tvmovie_genres": 10770,
    "thriller_genres": 53,
    "war_genres": 10752,
    "western_genres": 37,
}

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  const [response, setResponse] = useState({});
  const [data, setData] = useState([]);
  const [displayData, setDisplayData] = useState([]);
  const [isSelected, setSelection] = useState(false);
  const [search, setSearch] = useState('');


  // https://developers.themoviedb.org/3/discover/movie-discover
  const [filters, setFilters] = useState({
    primary_release_year: undefined,
    selectedGenres: []
  });

  const queryFromFilter = () => {
    let queryString = "";
    if( filters.primary_release_year ) {
      queryString += `primary_release_year=${filters.primary_release_year}`;
    }
    if( filters.selectedGenres.length > 0 ) {
      queryString += `&with_genres=${filters.selectedGenres.join(',')}`;
    }
    return queryString;
  }

  // I *think* the search was bombing out because for whatever reason, some 
  // of the numerical conversions (parseInt) were failing. 
  // I've added a check to prevent this. 

  const applyFilters = (dataToFilter = data) => {
    let newDisplayData = [...dataToFilter];

    if( filters.primary_release_year ) {
      newDisplayData = newDisplayData.filter( movie => {
        const year = parseInt(movie.release_date.split("-")[0]);
        return year !== NaN && year === filters.primary_release_year;
      });
    }      

    // Here is an example of filtering based off the genre selections

    if( filters.selectedGenres.length > 0 ) {
      newDisplayData = newDisplayData.filter( movie => {
        for( let genre of filters.selectedGenres ) {
          console.log( `looking for ${genre} in: `);
          console.log( movie.genre_ids )
          if( movie.genre_ids.includes(genre) ) {
            return true;
          }
        }
        return false;
      })
    }

    setDisplayData(newDisplayData);
  }

  useEffect( () => {
    applyFilters();
  },[filters]);

  useEffect( () => {
    const getMovies = async () => {
      await axios.get(`https://api.themoviedb.org/3/search/movie?api_key=${TMDB_KEY}&language=en-US&query=${search}&page=1&include_adult=false`)
        .then( (r) => { 
          setResponse( r.data );
          setData(r.data.results);
          applyFilters(r.data.results)
        })
        .catch( (e) => {
          console.log(`error ${e}`);
        });
    };
   const getMovies2 = async () => {
      await axios.get(`https://api.themoviedb.org/3/discover/movie?api_key=${TMDB_KEY}&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=1&${queryFromFilter()}`)
        .then( (r) => { 
          setResponse( r.data );
          setData(r.data.results)
        })
        .catch( (e) => {
          console.log(`error ${e}`);
        });
    };    
    if( search !== '' ) { 
      getMovies();
    } else {
      getMovies2();
    }
  },[search, filters]);
  

//useEffect ( ( ) =>  {
//    const getMovies2 = async () => {
//       await axios.get(`https://api.themoviedb.org/3/discover/movie?api_key=${TMDB_KEY}&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=1&${queryFromFilter()}`)
//         .then( (r) => { 
//           setResponse( r.data );
//           setData(r.data.results)
//         })
//         .catch( (e) => {
//         });
//     };
//     getMovies();
//   },[filters]);}

  const decrementYear = () => {
    setFilters({ ...filters, primary_release_year: filters.primary_release_year ?  filters.primary_release_year-1 : 2021 })
  }

   const decrement10Year = () => {
    setFilters({ ...filters, primary_release_year: filters.primary_release_year ?filters.primary_release_year-10 : 2021 })
  }
  const add1Year = () => {
    setFilters({ ...filters, primary_release_year: filters.primary_release_year ?filters.primary_release_year+1 : 2021 })
  }

  const add10Year = () => {
    setFilters({ ...filters, primary_release_year: filters.primary_release_year ?filters.primary_release_year+10 : 2021})
  }

  const resetYear = () => {
    setFilters({ ...filters, primary_release_year: filters.primary_release_year ?filters.primary_release_year === undefined : 2021})
  }
  const resetYear2 = () => {
    setFilters({ ...filters, primary_release_year: filters.primary_release_year })
  }


  const toggleGenre = (genre) => {
    let genres = [...filters.selectedGenres];
    if( genres.includes(genre) ) {
      genres = genres.filter( g => g!=genre );
    } else {
      genres.push(genre);
    }
    setFilters({...filters, selectedGenres: genres});
    
  }

  // const toggleFix = (genre) => {
  //   let genres = [...filters.selectedGenres];
  //   if( genres.includes(genre) ) {
  //     genres = genres.filter( g => g!=genre );
  //   } else {
  //     genres.push(genre);
  //   }
  //   setFilters({...filters, selectedGenres: genres});
    
  // }



  const renderRow = ({item}) => {
    
    return (
      <Card style={styles.card}>
        <Card.Title  title={item.original_title} subtitle={`released: ${item.release_date}`}  />
        <Card.Content>
        <Text>Rating: {item.vote_average} / 10</Text>
        <Text>-----------------</Text>
        <Text>{item.overview}</Text>
         
        </Card.Content>
      </Card>
    )    
  }

  const buttons = Object.keys(genres).map( key => {
    return (<Button color={filters?.selectedGenres.includes(genres[key]) ? '#CCCCFF' : '#5F9EA0'
    } onPress={()=> toggleGenre(genres[key])} title= {key.split("_").join(" ")} />)
    
  });

  return (

    
    <View style={styles.container}>
    <ScrollView>
     <Text style={{color: '#CCCCFF', fontSize: 33, fontWeight: 'bold',marginBottom: 24}}> ─The Movie App─</Text>


     
    <Text style={{color: '#5F9EA0', fontSize: 14, fontWeight: 'bold',marginBottom: 24}}>    🎥Cant Find Find A Movie To Watch?🎥</Text>
    <Text style={{color: 'white', fontSize: 12,marginBottom: 10}}>Filter Through 711,991 Movies Using The Options Below.</Text>
  
  
     
 <SearchBar
        placeholder="Type Here..."
        onChangeText={setSearch}
        value={search}
      />

     {buttons}

<Text style={{color: '#F0FFFF', fontSize: 15, fontWeight: 'bold',marginBottom: 11}}>              ──────────────────</Text>

<Text style={{color: '#F0FFFF', fontSize: 15, fontWeight: 'Heavy',marginBottom: 24}}>                      Selected Year: {filters.primary_release_year}</Text>

<Chip onPress={() => resetYear()}>                          Reset Year                           </Chip>
<Text> </Text>
<Chip onPress={() => resetYear2()}>                       Apply Year Filter                           </Chip>


 <Text> </Text>

     
      <Chip onPress={() => decrementYear()}>                   -1 Release Date Year                             </Chip>

              <Text> </Text>

     
      <Chip onPress={() => add1Year()}>                   +1 Release Date Year                             </Chip>

            <Text> </Text>
     
      <Chip onPress={() => decrement10Year()}>                   -10 Release Date Year                             </Chip>

            <Text> </Text>
     
      <Chip onPress={() => add10Year()}>                   +10 Release Date Year                             </Chip>
  

      <Text style={{color: '#F0FFFF', fontSize: 15, fontWeight: 'bold',marginTop: 11}}>             ──────────────────</Text>
    
      
     
  
      


      <FlatList
        data={displayData}
        renderItem={renderRow}
        keyExtractor={item=>item[0]}
      />
      </ScrollView>
    </View>
    
  );
}




// https://reactnative.dev/docs/flexbox
// https://css-tricks.com/snippets/css/a-guide-to-flexbox/
const styles = StyleSheet.create({
  card:{
    margin: 2,
    backgroundColor: '#AED4FB',
    
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#263350',
    padding: 8,
    
  },
});


